start_text = '''Kon'nichiwa!!! If you are looking for somewhere to watch/download anime or read manga then cheers! you are in a right place this bot has it all. \n\nFor latest releases visit our [channel](https://t.me/latest_ongoing_airing_anime)
                
Just send /help to know more about me  
'''

help_text = '''List of commands:
/anime <Anime name> : to download+stream any anime by search. Use of AD-BLOCKERS are suggested when using the links provided by bot (Personally I suggest using brave browser)

/latest : to get list of latest episodes released

/batch <Anime id><from episode>:<to episode> : For getting download+stream links in bulk\nFor instance /batch Jujutsu-Kaisen-TV:1:12 \n(get the anime id by using the /anime command first)

/download : same as batch download but you get 1 file you can import in **1DM/ADM** (here the highest possible resolution is provided so if you want to choose resolution use old batch command)

/manga  <name of manga you want> : to read manga by search
                
The links provided are in multiple qualities to download just open links in browser and download starts automatically
                
**(HDP-mp4)** links can be direclty opened in VLC, Xplayer or MX player to stream episodes without downloading

**MixdropSV** links usually have lowest size for 720p
                
Use **1DM/ADM** to manage your batch downloading processess.

To report any Problems, just hit towards the [Group discussion chat](https://t.me/animechatterbox)'''

